//index.js
Page({
  data:{
    text:"初始数据",
    array:[{msg:"初始数据"}],
    data:{
      inner:"初始数据"
    }
  },
  changeText:function(){
    //this.data.text = "修改后的数据"  //bad
    this.setData({
      text:"修改后的数据"
    })
  },
  changeItemInArray:function(){
    //可以只修改array中某个item
    this.setData({
      "array[0]" : {msg:"修改后的数据"} //修改data.array的第一个元素,[]中只能是数字
    })
  },
  changeKeyInObject:function(){
    //可以只修改Object中的某个key
    this.setData({
      "data.inner":"修改后的数据" //修改data.data.inner
    });
  },
  asyncSetData:function(){
    var self = this;
    setTimeout(function(){
      self.setData({
        text:"异步设置"
      })
      self.update()
    },3000)
  }
})