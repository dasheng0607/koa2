//index.js
Page({
  data:{
    text:"这是一个页面"
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onMenuShareAppMessage: function () {
    return {
      title: '自定义标题', // 分享标题，默认为应用名字
      path: 'anypath/anypage?id=123', // 分享的页面路径，默认为当前页 path
      imgUrl: 'http://example.com/a.jpg' // 分享的图片链接，支持 HTTP(s) 链接及应用相对路径，默认为应用logo
    }
  },
  onMenuShareTimeline: function () {
    return {
      title: '自定义标题', // 分享标题，默认为应用名字
      path: 'anypath/anypage?id=123', // 分享的页面路径，默认为当前页 path
      imgUrl: 'http://example.com/a.jpg' // 分享的图片链接，支持 HTTP(s) 链接及应用相对路径，默认为应用logo
    }
  },
  //下拉刷新监听
  onPullDownRefresh: function () {
    setTimeout(function(){
      wx.stopPullDownRefresh()
    },3000)
  },
  bindViewTap:function(){
    this.setData({
      text:"hello world"
    })
  }
})