//index.js
Page({
  onPullDownRefresh:function(){
    setTimeout(function(){
      wx.stopPullDownRefresh();
    })
  }
})